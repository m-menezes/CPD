    function loadCSS(url) {

      if($("#contraste").length ==1){
        $("#contraste").remove();
        $('body').removeClass('contraste');

        // IMAGEM UFSM NORMAL
        $(".brasaoUFSM").attr('src', '/modules/mod_ufsm_logo/images/brasao-cores.png');
      }
      else{
        // IMAGEM UFSM CONTRASTE
        $(".brasaoUFSM").attr('src', '/modules/mod_ufsm_logo/images/brasao-linhas.png');

        var lnk = document.createElement('link');
        lnk.setAttribute('type', "text/css" );
        lnk.setAttribute('rel', "stylesheet" );
        lnk.setAttribute('id', "contraste" );
        lnk.setAttribute('href', url );       
        $('body').addClass('contraste');
        document.getElementsByTagName("head").item(0).appendChild(lnk);
      }
    }
