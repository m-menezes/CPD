<?php
/**
 * @package     Marcelo Menezes S.
 * @subpackage  mod_ufsm_logo
 *
 * @copyright   Copyright (C) 2017. All rights reserved.
 */


defined('_JEXEC') or die;
class ModUFSMLogoHelper{

    public static function getList($params){
    	return $params;
    }
}
