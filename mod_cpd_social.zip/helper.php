<?php
/**
 * @package     Marcelo Menezes S.
 * @subpackage  mod_cpd_social
 *
 * @copyright   Copyright (C) 2017. All rights reserved.
 */


defined('_JEXEC') or die;
class ModSocialHelper{

    public static function getList($params){
    	return $params;
    }
}
