<?php
/**
 * @package     Marcelo Menezes S.
 * @subpackage  mod_cpd_facebook
 *
 * @copyright   Copyright (C) 2017. All rights reserved.
 */


defined('_JEXEC') or die;
class ModFacebookHelper{

    public static function getList($params){
    	return $params;
    }
}
