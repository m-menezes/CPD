<?php
/**
 * @package     Marcelo Menezes S.
 * @subpackage  mod_cpd_footer
 *
 * @copyright   Copyright (C) 2017. All rights reserved.
 */


defined('_JEXEC') or die;
class ModCPDFooterHelper{

    public static function getList($params){
    	return $params;
    }
}
