<?php
/**
 * @package     Marcelo Menezes S.
 * @subpackage  mod_cpd_links
 *
 * @copyright   Copyright (C) 2017. All rights reserved.
 */


defined('_JEXEC') or die;
class ModCPDLinkHelper{

    public static function getList($params){
    	return $params;
    }
}
