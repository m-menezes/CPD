<?php
/**
 * @package     Marcelo Menezes S.
 * @subpackage  mod_cpd_visual
 *
 * @copyright   Copyright (C) 2017. All rights reserved.
 */


defined('_JEXEC') or die;
class ModCPDVisualHelper{

    public static function getList($params){
    	return $params;
    }
}
