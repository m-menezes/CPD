<?php
/**
 * @package     Marcelo Menezes S.
 * @subpackage  mod_cpd_mapasite
 *
 * @copyright   Copyright (C) 2017. All rights reserved.
 */


defined('_JEXEC') or die;
class ModSlideshowHelper{

    public static function getList($params){
    	return $params;
    }
}
