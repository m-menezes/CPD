<?php
/**
 * @package     mod_wgajaxcontato - WG Ajax Contato Módulo
 * @version     2.0
 * @created     Jul 2015
 *
 * @author      Lauro W. Guedes
 * @email       leo-ti@hotmail.com
 * @website     http://leowgweb.com.br
 * @support     Suporte - http://leowgweb.com.br/contato
 * @copyright   Copyright (C) 2015 Lauro W. Guedes.Todos os Direitos Reservados.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 *
 */

$obj = json_decode($_POST['arrSerial']);
 
// Passando os dados obtidos pelo formulário para as variáveis abaixo
$nome = $_POST['nome']; //PEGA O NOME DO REMETENTE
$email = $_POST['email']; //PEGA O E-MAIL DO REMETENTE
$assunto = $_POST['assunto']; //PEGA O ASSUNTO
$msn = "<h3>Contato enviado do site.</h3><p><strong>Nome: </strong>$nome</p><p><strong>E-mail: <strong>$email</p><p><strong>Mensagem</strong></p>";
$msn .= $_POST['msn']; //PEGA A MENSAGEM
$para = $obj->{'destinatario'}; //E-MAIL DO DESTINATÁRIO
$mensagem_retorno = $obj->{'mensagem'}; //PEGA A MENSAGEM DE ENVIADO COM SUCESSO

$smtpautenticacao = $obj->{'smtpautenticacao'};
$smtpseguranca = $obj->{'smtpseguranca'};
$smtpporta = $obj->{'smtpporta'};
$smtpusuario = $obj->{'smtpusuario'};
$smtpsenha = $obj->{'smtpsenha'};
$smtphost = $obj->{'smtphost'};

require 'phpmailer/PHPMailerAutoload.php';

$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = $smtphost;  // Specify main and backup SMTP servers
$mail->SMTPAuth = $smtpautenticacao;                             // Enable SMTP authentication
$mail->Username = $smtpusuario;                 // SMTP username
$mail->Password = $smtpsenha;                           // SMTP password
$mail->SMTPSecure = $smtpseguranca;                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = $smtpporta;                                    // TCP port to connect to

$mail->From = $email;
$mail->FromName = $nome;
$mail->addAddress($para);     // Add a recipient
$mail->addReplyTo($email, $nome);
// $mail->addCC($ccpara);
// $mail->addBCC('bcc@example.com');

// $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
// $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = $assunto;
$mail->Body    = $msn;
// $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

if(!$mail->send()) {
    echo $mail->ErrorInfo;
} else {
    echo $mensagem_retorno;
}
?>